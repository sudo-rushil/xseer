# XSeer

Deep learning for fast, accurate denoising of astronomical spectra.

# Overview

## Requirements

XSeer is designed for use with Python 3 only. It has three requirements:

 - Tensorflow 2.x
 - Astropy
 - Numpy

# TODO:

 - Two functions
  - rewrite fits/write new fits
  - display plot
